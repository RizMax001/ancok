// config.js
const config = {
  openaiApiKey: '', // Ganti dengan API key kamu
  creator: 'Rizky Max',
};

export default config;
